package com.Google.game.utils;

public interface GameConstants{
	String Title = ConfigReader.getValue("Game.title");
	int GWidth = Integer.parseInt(ConfigReader.getValue("Game.width"));
	int GHeight = Integer.parseInt(ConfigReader.getValue("Game.height"));
	int Floor = GHeight - 200;
	int RightKey = 68;
	int LeftKey = 65;
	int SPEED = 5;
	int OppLeft = 100;
	int OppRight = 102;
	int Ki_ck = 69;
	int walk = 1;
	int Po_wer =88;
	int gravity = 1;
	int Ju_mp = 32;
	int damge = 5;
	int punch = 81;
	int oppkick = 105;
	int oppjump = 104;
	int opppunch = 103;
	int max_HP = 500;
	int Opp_power=97;
}
