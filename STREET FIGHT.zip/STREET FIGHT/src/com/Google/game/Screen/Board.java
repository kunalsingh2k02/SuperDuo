package com.Google.game.Screen;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.Google.game.player.Energy;
import com.Google.game.player.RyePlayer;
import com.Google.game.player.Versus;
import com.Google.game.player.kenPlayer;
import com.Google.game.utils.GameConstants;

public class Board extends JPanel implements GameConstants{
	BufferedImage image;
	private Versus newv;
	private RyePlayer player;
	private kenPlayer Opp;
	private Timer timer,t2;
	private Energy ryuMaxHp;
	private Energy kenMaxHp;
	private boolean gameOver;
	private void loadHp() {
		ryuMaxHp = new Energy(30,"KING");
		kenMaxHp = new Energy(GWidth-550,"LEE");
	}
	private void printHp(Graphics g) {
		ryuMaxHp.printRect(g);
		kenMaxHp.printRect(g);
		
	}
	private void gameLoop() {
		timer = new Timer(100,new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(gameOver==true) {
					timer.stop();
				}
				isGameOver();
				collision();
				repaint();
			}
		});
		timer.start();
		t2 = new Timer(25,new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(gameOver==true) {
					timer.stop();
				}
				player.fall();
				Opp.fall();
			}
		});
		t2.start();
		
	}
	private void isGameOver() {
		if(ryuMaxHp.getHealth()<=0||kenMaxHp.getHealth()<=0) {
			gameOver = true;
		}
	}
	private void printGameOver(Graphics pen) {
		if(gameOver==true) {
			pen.setColor(Color.cyan);
			pen.setFont(new Font("times",Font.BOLD,100));
			pen.drawString("GAME OVER",GWidth/2-150,GHeight/2-100);
		}
	}
	private boolean isCollide() {
		int xDist = Math.abs(player.getX()- Opp.getX());
		int yDist = Math.abs(player.getY()-Opp.getY());
		int maxH = Math.max(player.getH(),Opp.getH());
		int maxW = Math.max(player.getW(),Opp.getW());
		int mPow = Math.abs(player.getM()-Opp.getX());
		int kPow = Math.abs(Opp.getM()-player.getX());
		
		return (xDist<=(maxW-20) && yDist<=(maxH-20))||(mPow<=player.getW()-20)||(kPow<=Opp.getW()-20);
	}
	private void collision() {
		if(isCollide()) {
			if(player.isAttacking()) {
				Opp.setCurrentmove(damge);
				kenMaxHp.setHealth();
			}
			if(Opp.isAttacking()) {
				player.setCurrentmove(damge);
				ryuMaxHp.setHealth();
			}
			Opp.setCollide(true);
			Opp.setSpeed(0);
			player.setCollide(true);
			player.setTrigger(false);
			Opp.setTrigger(false);
			player.setSpeed(0);
			System.out.println("YESS!");
		}
		else {
			player.setCollide(false);
			player.setSpeed(SPEED);
			Opp.setCollide(false);
			Opp.setSpeed(SPEED);
		}
	}
	public Board() throws IOException{
		player = new RyePlayer();
		Opp = new kenPlayer();
		newv= new Versus();
		setFocusable(true);
		loadBackgroundImage();
		bindEvents();
		gameLoop();
		loadHp();
	}
	public void bindEvents() {
		KeyListener listener = new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				System.out.println("Typed"+ e.getKeyCode()+"  "+ e.getKeyChar());
			}
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==RightKey) {
					player.setSpeed(SPEED);
					player.move();
				}
				if(e.getKeyCode()==LeftKey) {
					player.setCollide(false);
					player.setSpeed(-SPEED);
					player.move();
					
				}if(e.getKeyCode()==OppRight) {
					Opp.setCollide(false);
					Opp.setSpeed(SPEED);
					Opp.move();
				}if(e.getKeyCode()==oppkick){
					Opp.setCurrentmove(oppkick);
				}
				if(e.getKeyCode()==OppLeft) {
					Opp.setSpeed(-SPEED);
					Opp.move();
				}if(e.getKeyCode()==Ki_ck) {
					player.setCurrentmove(Ki_ck);
				}if(e.getKeyCode()==punch) {
					player.setCurrentmove(punch);
				}
				if(e.getKeyCode()==Po_wer) {
					player.setCurrentmove(Po_wer);
				}if(e.getKeyCode()==Opp_power) {
					Opp.setCurrentmove(Opp_power);
				}
				if(e.getKeyCode()==Ju_mp) {
					player.jump();
				}if(e.getKeyCode()==oppjump) {
					Opp.jump();
				}if(e.getKeyCode()==opppunch){
					Opp.setCurrentmove(opppunch);
				}
				
				// TODO Auto-generated method stub
				System.out.println("Pressed"+ e.getKeyCode()+"  " +e.getKeyChar());	
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				System.out.println("Released"+ e.getKeyCode()+"  "+e.getKeyChar());		
			}
			
		};
		this.addKeyListener(listener);
	}
	public void loadBackgroundImage() {
		try {
			image = ImageIO.read(Board.class.getResource("new_bg.jpg"));
		}catch(Exception e) {
			JOptionPane.showMessageDialog(this,"OOPS! SOWETHING WENT WRONG!");
			System.out.println(e);
			System.exit(0);
		}
	}
	@Override
	public void paintComponent(Graphics pen){
		super.paintComponent(pen);
		printBG(pen);
		player.drawPlayer(pen);
		Opp.drawPlayer(pen);
		newv.drawPlayer(pen);
		printHp(pen);
		printGameOver(pen);
	}
	private void printBG(Graphics pen) {
		pen.drawImage(image,0,0,GWidth,GHeight,null);
	}
}
