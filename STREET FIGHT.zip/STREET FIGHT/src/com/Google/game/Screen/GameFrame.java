package com.Google.game.Screen;
import java.io.IOException;

import javax.swing.JFrame;

import com.Google.game.utils.GameConstants;


public class GameFrame extends JFrame implements GameConstants{
	public GameFrame() throws IOException {
		setTitle(Title);
		setResizable(false);
		setSize(GWidth,GHeight);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Board board = new Board();
		add(board);
		setVisible(true);
	}

	public static void main(String[] args) {
		try {
			GameFrame frame = new GameFrame();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}