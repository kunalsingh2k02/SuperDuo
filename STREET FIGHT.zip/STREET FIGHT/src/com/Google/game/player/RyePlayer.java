package com.Google.game.player;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Timer;


public class RyePlayer extends Player{
	private BufferedImage walkImage [] = new BufferedImage[6];
	private BufferedImage kick[]= new BufferedImage[6];
	private BufferedImage power[]= new BufferedImage[10];
	private BufferedImage fire[]=new BufferedImage[8];
	private BufferedImage punchImages[]=new BufferedImage[6];
	private BufferedImage dmg[]=new BufferedImage[6];
	private boolean trigger;

	public boolean isTrigger() {
		return trigger;
	}
	public void setTrigger(boolean trigger) {
		this.trigger = trigger;
	}
	public RyePlayer()throws IOException {
		image = ImageIO.read(RyePlayer.class.getResource("player-sprite.gif"));	
		LaodWalkImage();
		KickImage();
		damgeEffect();
		PowerMove();
		iceFire();
		loadPunchImage();
	}
	public void jump() {
		if(!isjump) {
			isjump = true;
		    force = -10;
		    y=y+force;
		}
	}
	public void fall() {
		if(y>=(Floor-h)) {
			isjump = false;
			return;
		}
		y = y+force;
		force = force+gravity;
	}
	public void damgeEffect() {
		dmg[0]=image.getSubimage(221,2424,73,96);
		dmg[1]=image.getSubimage(221,2424,73,96);
		dmg[2]=image.getSubimage(330,2528,79,98);
		dmg[3]=image.getSubimage(330,2528,79,98);
		dmg[4]=image.getSubimage(233,2528,78,98);
		dmg[5]=image.getSubimage(233,2528,78,98);
	}
	private void loadPunchImage() {
		punchImages[0] = image.getSubimage(26,819,70,102);
		punchImages[1] = image.getSubimage(106,821,72,100);
		punchImages[2] = image.getSubimage(187,821,115,100);
		punchImages[3] = image.getSubimage(310,819,78,99);
		punchImages[4] = image.getSubimage(402,816,108,102);
		punchImages[5] = image.getSubimage(517,821,79,100);
	}
	private void LaodWalkImage() {
		walkImage[0]=image.getSubimage(61,236,73,98);
		walkImage[1]=image.getSubimage(142,235,77,98);
		walkImage[2]=image.getSubimage(225,236,60,98);
		walkImage[3]=image.getSubimage(304,233,58,99);
		walkImage[4]=image.getSubimage(377,234,73,98);
		walkImage[5]=image.getSubimage(453,239,65,96);
	}
	public void KickImage() {
		kick[0]= image.getSubimage(40,1044,68,99);
		kick[1]= image.getSubimage(119,1044,69,100);
		kick[2]= image.getSubimage(200,1047,118,97);
		kick[3]= image.getSubimage(330,1045,65,102);
		kick[4]= image.getSubimage(408,1045,65,102);
		kick[5]= image.getSubimage(484,1045,89,102);
		
	}
	private void PowerMove() {
		power[0]=image.getSubimage(24,1704,113,92);
		power[1]=image.getSubimage(146,1704,99,92);
		power[2]=image.getSubimage(248,1704,111,92);
		power[3]=image.getSubimage(370,1704,94,92);
		power[4]=image.getSubimage(472,1704,122,92);
		power[5]=image.getSubimage(2,1811,118,94);
		power[6]=image.getSubimage(124,1811,119,94);
		power[7]=image.getSubimage(249,1811,124,94);
		power[8]=image.getSubimage(382,1811,102,94);
		power[9]=image.getSubimage(489,1811,148,94);
	}
	public  void iceFire() {
		fire[0]=image.getSubimage(11,3110,63,34);
		fire[1]=image.getSubimage(79,3110,79,34);
		fire[2]=image.getSubimage(165,3110,54,34);
		fire[3]=image.getSubimage(228,3110,81,34);
		fire[4]=image.getSubimage(319,3110,61,34);
		fire[5]=image.getSubimage(392,3110,75,34);
		fire[6]=image.getSubimage(476,3110,58,34);
		fire[7]=image.getSubimage(540,3110,84,34);
	}
	public BufferedImage Fi_re() {
		m=m+100;
		if(imageIndex>7) {
			imageIndex=0;	
		}
		if(m>=(x+800)) {
			trigger=false;
		}
		isAttacking = true;
		BufferedImage imk = fire[imageIndex];
		imageIndex++;
		return imk;
	}
	@Override
	public BufferedImage printfire(){
		if (trigger==true){
			return Fi_re();
		}
		else {
			m=x;
			return null;
		}
	}
	
	private BufferedImage printPower(){
		if(imageIndex>9) {
			imageIndex=0;
			trigger=true;
			currentmove=walk;
		}
		BufferedImage imk = power[imageIndex];
		imageIndex++;
		return imk;
		
	}
	private BufferedImage printWalk() {
		isAttacking=false;
		if(imageIndex>5) {
			imageIndex=0;
		}
		BufferedImage img = walkImage[imageIndex];
		imageIndex++;
		return img;
	}
	private BufferedImage printpunch() {
		if(imageIndex>5) {
			imageIndex=0;
			currentmove=walk;
			isAttacking = false;
		}
		isAttacking = true;
		BufferedImage tic = punchImages[imageIndex];
		imageIndex++;
		return tic;
	}
	private BufferedImage printkick() {
		if(imageIndex>5) {
			imageIndex=0;
			currentmove=walk;
			isAttacking = false;
		}
		isAttacking = true;
		BufferedImage tic = kick[imageIndex];
		imageIndex++;
		return tic;
	}private BufferedImage printDmg() {
		if(imageIndex>5) {
			imageIndex=0;
			currentmove = walk;
		}
		BufferedImage img = dmg[imageIndex];
		imageIndex++;
		return img;
	}
	public BufferedImage walk() {
		if(currentmove==Ki_ck) {
			return printkick();
		}else if(currentmove==damge) {
			return printDmg();
		}
		else if (currentmove==punch) {
			return printpunch();
		}
		else if(currentmove==Po_wer) {
			return printPower();
		}
			return printWalk();
		}
}


