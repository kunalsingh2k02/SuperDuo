package com.Google.game.player;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import com.Google.game.utils.*;

public class Player extends CommonPlayer implements GameConstants{
	public Player() throws IOException {
		x = 100;
		h = 130;
		w = 130;
		y = Floor-h;
		image = ImageIO.read(Player.class.getResource("player-sprite.gif"));
	}
	@Override
	public BufferedImage walk() {
		 return image.getSubimage(61,236,73,99);
	}
	@Override
	public BufferedImage printfire() {
		return null;
	}
}
