package com.Google.game.player;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class kenPlayer extends OppPlayer{
	private BufferedImage walkImage[]= new BufferedImage[6];
	private BufferedImage dmg[]=new BufferedImage[8];
	private BufferedImage kickImages[]=new BufferedImage[9];
	private BufferedImage punchImages[]=new BufferedImage[6];
	private BufferedImage power[]= new BufferedImage[4];
	private BufferedImage fire[]=new BufferedImage[8];
	private boolean trigger;
	public boolean isTrigger() {
		return trigger;
	}
	public void setTrigger(boolean trigger) {
		this.trigger = trigger;
	}
	public kenPlayer() throws IOException{
		image = ImageIO.read(Player.class.getResource("kenimage.png"));
		LoadWalkImage();
		damgeEffect();
		loadKickImage();
		loadPunchImage();
		PowerMove();
		iceFire();}
	public void jump() {
		if(!isjump) {
			isjump = true;
		    force = -10;
		    y=y+force;
		}
	}
	public void fall() {
		if(y>=(Floor-h)) {
			isjump = false;
			return;
		}
		y = y+force;
		force = force+gravity;
	}
	private void PowerMove() {
		power[0]=image.getSubimage(2020,2740,71,91);
		power[1]=image.getSubimage(1918,2744,90,90);
		power[2]=image.getSubimage(1816,2744,94,90);
		power[3]=image.getSubimage(1696,2744,110,90);
		}
	
	private void loadPunchImage() {
		punchImages[0] = image.getSubimage(1252,1144,111,99);
		punchImages[1] = image.getSubimage(1373,1152,72,92);
		punchImages[2] = image.getSubimage(1517,1149,63,93);
		punchImages[3] = image.getSubimage(1667,1143,109,100);
		punchImages[4] = image.getSubimage(1786,1148,78,95);
		punchImages[5] = image.getSubimage(1932,1154,96,87);
	}
	public void damgeEffect() {
		dmg[0]=image.getSubimage(1439,3273,84,95);
		dmg[1]=image.getSubimage(1539,3276,74,92);
		dmg[2]=image.getSubimage(1627,3276,72,92);
		dmg[3]=image.getSubimage(1708,3276,65,92);
		dmg[4]=image.getSubimage(1790,3276,78,92);
		dmg[5]=image.getSubimage(1876,3276,75,92);
		dmg[6]=image.getSubimage(1954,3276,74,92);
		dmg[7]=image.getSubimage(2033,3276,64,92);
		
	}
	public void LoadWalkImage() {
		walkImage[0]=image.getSubimage(1263,863,62,97);
		walkImage[1]=image.getSubimage(1334,862,62,96);
		walkImage[2]=image.getSubimage(1406,862,64,93);
		walkImage[3]=image.getSubimage(1478,864,63,92);
		walkImage[4]=image.getSubimage(1548,863,64,95);
		walkImage[5]=image.getSubimage(1618,868,64,90);
	}
	private void loadKickImage() {
		kickImages[0] = image.getSubimage(882,1579,71,82);
		kickImages[1] = image.getSubimage(985,1583,106,80);
		kickImages[2] = image.getSubimage(1105,1567,122,93);
		kickImages[3] = image.getSubimage(1238,1564,94,99);
		kickImages[4] = image.getSubimage(1348,1570,64,90);
		kickImages[5] = image.getSubimage(1427,1565,64,93);
		kickImages[6] = image.getSubimage(1494,1561,117,97);
		kickImages[7] = image.getSubimage(1623,1563,68,93);
		kickImages[8] = image.getSubimage(2035,1568,62,92);
	}
	public BufferedImage printfire(){
		if (trigger==true){
			return Fi_re();
		}
		else {
			m=x;
			return null;
		}
	}
	public  void iceFire() {
		fire[0]=image.getSubimage(1486,2760,31,39);
		fire[1]=image.getSubimage(1486,2760,31,39);
		fire[2]=image.getSubimage(1524,2760,34,36);
		fire[3]=image.getSubimage(1524,2760,34,36);
		fire[4]=image.getSubimage(1576,2760,64,36);
		fire[5]=image.getSubimage(1576,2760,64,36);
		fire[6]=image.getSubimage(1647,2756,52,38);
		fire[7]=image.getSubimage(1647,2756,52,38);
	}
	public BufferedImage Fi_re() {
		m=m-100;
		if(imageIndex>7) {
			imageIndex=0;	
		}
		if(m<=(x-800)) {
			trigger=false;
		}
		isAttacking = true;
		BufferedImage imk = fire[imageIndex];
		imageIndex++;
		return imk;
	}
	private BufferedImage printPower(){
		if(imageIndex>3) {
			imageIndex=0;
			trigger=true;
			currentmove=walk;
		}
		BufferedImage imk = power[imageIndex];
		imageIndex++;
		return imk;
	}
	private BufferedImage printKick() {
		if(imageIndex>8) {
			imageIndex=0;
			isAttacking = false;
			currentmove = walk;
		}
		isAttacking = true;
		BufferedImage img = kickImages[imageIndex];
		imageIndex++;
		return img;
	}
	private BufferedImage printPunch() {
		if(imageIndex>5) {
			imageIndex=0;
			isAttacking = false;
			currentmove = walk;
		}
		isAttacking = true;
		BufferedImage img = punchImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	private BufferedImage printWalk() {
		isAttacking=false;
		if(imageIndex>5) {
			imageIndex =0;	
		}
		 BufferedImage img = walkImage[imageIndex];
		 imageIndex++;
		 return img;	 
	}
	private BufferedImage printDmg() {
		if(imageIndex>7) {
			imageIndex=0;
			currentmove = walk;
		}
		BufferedImage img = dmg[imageIndex];
		imageIndex++;
		return img;
	}
	@Override
	public BufferedImage walk() {
		if(currentmove==damge) {
			return printDmg();
		}else if(currentmove==oppkick) {
			return printKick();
		}
		else if(currentmove==opppunch) {
			return printPunch();
		}else if(currentmove==Opp_power) {
			return printPower();
		}
		else {
			return printWalk();
		}	
	}
}
