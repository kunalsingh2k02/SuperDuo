package com.Google.game.player;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import com.Google.game.utils.GameConstants;

public abstract class CommonPlayer implements GameConstants{
	protected int x;
	protected int w;
	protected int y;
	protected int h;
	protected int m;
	protected int health=max_HP;
	public CommonPlayer(){
		health = max_HP;
	}
	
	public int getHealth() {
		return health;
	}
	public void setHealth() {
		this.health =(int)(this.health-(max_HP*0.03));
	}
	protected boolean isCollide;
	public boolean isCollide() {
		return isCollide;
	}
	public void setCollide(boolean isCollide) {
		this.isCollide = isCollide;
	}
	public int getM() {
		return m;
	}
	public void setM(int m) {
		this.m=m;
		m=getX()+100;
	}
	protected int speed;
	protected int imageIndex;
	protected int currentmove;
	protected BufferedImage image;
	protected int force;
	protected boolean isjump;
	abstract public BufferedImage walk();
	abstract public BufferedImage printfire();
	protected boolean isAttacking;
	public boolean isAttacking() {
		return isAttacking;
	}
	public void setAttacking(boolean isAttacking) {
		this.isAttacking = isAttacking;
	}
	public void drawPlayer(Graphics pen) {
		pen.drawImage(walk(), x, y, w, h,null);
		pen.drawImage(printfire(),m,y,w,h,null);
	}
	public int getCurrentmove() {
		return currentmove;
	}
	public void setCurrentmove(int currentmove) {
		this.currentmove = currentmove;
	}
	public void move() {
		if(!isCollide()) {
			x=x+speed;
		}
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getW() {
		return w;
	}
	public void setW(int w) {
		this.w = w;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getH() {
		return h;
	}
	public void setH(int h) {
		this.h = h;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public BufferedImage getImage() {
		return image;
	}
	public void setImage(BufferedImage image) {
		this.image = image;
	}
	
	
}
