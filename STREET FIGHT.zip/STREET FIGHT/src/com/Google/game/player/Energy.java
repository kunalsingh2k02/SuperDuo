package com.Google.game.player;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Energy extends CommonPlayer {
	String name;
	public Energy(int x,String name) {
		this.x = x;
		y=100;
		h=30;
		w=500;	
		this.name =name;
	}
	public void printRect(Graphics pen) {
		pen.setColor(Color.green);
		pen.fillRect(x, y, w, h);
		pen.setColor(Color.blue);
		pen.fillRect(x, y,health,h);
		pen.setColor(Color.white);
		pen.setFont(new Font("times",Font.BOLD,40));
		pen.drawString(name,x, y+70);
	}

	@Override
	public BufferedImage walk() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BufferedImage printfire() {
		// TODO Auto-generated method stub
		return null;
	}

}
