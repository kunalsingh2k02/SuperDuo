package com.Google.game.player;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Versus extends CommonPlayer{
	public Versus() throws IOException {
		x=650;
		h=100;
		w=100;
		y=100;
	image = ImageIO.read(Versus.class.getResource("VersusPNG.png"));
	}


@Override
public BufferedImage walk() {
	// TODO Auto-generated method stub
	return image;
}

@Override
public BufferedImage printfire() {
	// TODO Auto-generated method stub
	return null;
}
}
