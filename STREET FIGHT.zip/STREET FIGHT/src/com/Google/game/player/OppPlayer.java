package com.Google.game.player;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.Google.game.utils.*;

public class OppPlayer extends CommonPlayer implements GameConstants{
	public OppPlayer() throws IOException{
		x = 1200;
		h = 130;
		w = 130;
		y = Floor-h;
		image = ImageIO.read(Player.class.getResource("kenimage.png"));	
	}
	@Override
	public BufferedImage walk() {
		 return image.getSubimage(1263,863, 62,97);
	}
	@Override
	public BufferedImage printfire() {
		// TODO Auto-generated method stub
		return null;
	}
}
